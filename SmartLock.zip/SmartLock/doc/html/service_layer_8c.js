var service_layer_8c =
[
    [ "uint32_t", "service_layer_8c.html#a06896e8c53f721507066c079052171f8", null ],
    [ "delay", "service_layer_8c.html#a9580e4ca3047c17d9716b02cec7d72ba", null ]
];