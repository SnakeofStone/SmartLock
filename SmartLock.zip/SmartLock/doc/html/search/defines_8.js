var searchData=
[
  ['mcgirclk_5falt_281',['MCGIRCLK_ALT',['../_p_w_m_8c.html#a86e5effa94e9321b7567009f8bb793e7',1,'PWM.c']]],
  ['mcgirclk_5fclk_282',['MCGIRCLK_CLK',['../_u_a_r_t_8c.html#af858294626d5da6c150af3872c38e94d',1,'UART.c']]],
  ['mux_5fas_5fpwm_283',['MUX_AS_PWM',['../_p_w_m_8c.html#a7ff7a88cdc8627733da4a8a704aecc7a',1,'PWM.c']]]
];
