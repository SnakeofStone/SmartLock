var searchData=
[
  ['delay_174',['delay',['../service_layer_8c.html#a9580e4ca3047c17d9716b02cec7d72ba',1,'delay(uint32_t count):&#160;serviceLayer.c'],['../service_layer_8h.html#a9580e4ca3047c17d9716b02cec7d72ba',1,'delay(uint32_t count):&#160;serviceLayer.c']]]
];
