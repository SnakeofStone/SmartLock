var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuv",
  1: "cgimpsu",
  2: "_cdgilmpuv",
  3: "fimnp",
  4: "u",
  5: "eip",
  6: "e",
  7: "_abcdfghmnoprst"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

