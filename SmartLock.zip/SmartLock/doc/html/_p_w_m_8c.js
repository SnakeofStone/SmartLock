var _p_w_m_8c =
[
    [ "CHANNEL", "_p_w_m_8c.html#ace6a11e892466500d47d1f45f042bc53", null ],
    [ "CMOD", "_p_w_m_8c.html#ab9555fbbec6649e632590a8914768dee", null ],
    [ "COUNTER_RESET", "_p_w_m_8c.html#a4e36e8cc7c1178a773669239544dbb62", null ],
    [ "DBGMODE_MASK", "_p_w_m_8c.html#a549ddef3f41b7e6b5f28d36d995639cc", null ],
    [ "HALF_WORD", "_p_w_m_8c.html#a1167341ced933fd0b8911e2bc2204d61", null ],
    [ "MCGIRCLK_ALT", "_p_w_m_8c.html#a86e5effa94e9321b7567009f8bb793e7", null ],
    [ "MUX_AS_PWM", "_p_w_m_8c.html#a7ff7a88cdc8627733da4a8a704aecc7a", null ],
    [ "PS_8", "_p_w_m_8c.html#a83eab3432f78f8041d140048f9bdc159", null ],
    [ "PWM_PIN", "_p_w_m_8c.html#af5a48adc9d939102a42f2829b7a1b8ac", null ],
    [ "TPM_CENTER_ALIGN", "_p_w_m_8c.html#ae37d50ad7aacfce19ba9d85b758cd66a", null ],
    [ "TPM_MINOFFSIDE", "_p_w_m_8c.html#a48bb357dca0a0b52bd0e66d7ad4d4068", null ],
    [ "TPM_MOD", "_p_w_m_8c.html#afa454650cc93a854b50e23a276086813", null ],
    [ "PWM_bfnAngleAdjustment", "_p_w_m_8c.html#a67e8fa60a6811fc55c50723aac816cd7", null ],
    [ "PWM_bfnChangeCounter", "_p_w_m_8c.html#a7fb09bd5880b724feaa6a06d7fe5782b", null ],
    [ "PWM_bInitialPosition", "_p_w_m_8c.html#ab9262a21c3b7c9878ff55f786c09a68b", null ],
    [ "PWM_vfnDriverInit", "_p_w_m_8c.html#a24b1baf0d44b868079594a28e5535190", null ],
    [ "PWM_vfnToggleSignal", "_p_w_m_8c.html#abd8f7960b1306185db9fa40db6c99390", null ]
];