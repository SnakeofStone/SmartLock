var mtb_8c =
[
    [ "__MTB_BUFFER_SIZE", "mtb_8c.html#a280fa7ef27831d752a5f4f6e86f422b7", null ],
    [ "__CR_MTB_BUFFER", "mtb_8c.html#ae3852ed507241629720fff28c5acc2fa", null ]
];